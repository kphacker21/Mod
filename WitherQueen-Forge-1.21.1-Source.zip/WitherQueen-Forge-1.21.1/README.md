# Wither Queen Recreation — Forge 1.21.1

An independent mod project created for Prakash from the two supplied Wither Queen reference clips. Version 0.1.0.

**This download contains source code and assets, not an installable JAR.** Forge dependencies could not be downloaded in the authoring environment (HTTP 403). The full mod has not been compiled or launched in Minecraft. The included build workflow is the next verification step; compile or runtime corrections may still be needed.

## What is included

- An original 160-cuboid character rig with black hair, crown, red eyes, skeletal armor, skirt panels, two floating skulls and paired crescent scythes.
- Idle and walk motion, awakening, two melee combos, dash, skull barrage, expanding eclipse ring and a soul beam.
- A second transformation at half health, followed by faster movement, shorter recovery and stronger attacks.
- A boss health bar; 600 health (300 hearts), 12 armor and 150 XP.
- Spawn egg, craftable summoning sigil, trophy crown and a usable Royal Scythe reward.
- Original pixel textures with emissive blade edges, eyes and gems. Vanilla Minecraft sounds.
- Server-side hit detection and synchronized animation timing. Server code does not import client classes.
- Attacks do not break terrain. No natural spawning or automatic changes to your world.

The source has no GeckoLib, Epic Fight, Ares, shaders or other mod dependencies. It requires **Minecraft Java Edition 1.21.1**, **Forge 52.1.0 or a later 52.x release**, and **Java 21**. It is not a Bedrock/Android add-on, Fabric mod or NeoForge mod.

## Build on GitHub, including from a phone

The separately supplied **build-wither-queen.yml** contains the complete source payload. Use that file if you do not want to upload a folder of source files.

1. Sign in at https://github.com in your browser. Create a new repository, for example `wither-queen`. Initialize it with a README.
2. In that repository, choose **Add file → Create new file**. If those controls are hidden on your phone, enable the browser's **Desktop site** option.
3. Enter this full filename: `.github/workflows/build-wither-queen.yml`.
4. Open the supplied `build-wither-queen.yml` file in a text viewer. Copy **all its text** and paste it into GitHub's new file editor. Do not paste the ZIP bytes or a download link.
5. Choose **Commit changes**. This starts the build. You can also open **Actions → Build Wither Queen - Forge 1.21.1 → Run workflow**.
6. When the run finishes with a green check, open it and scroll to **Artifacts**. Download **WitherQueen-Forge-1.21.1-JAR**.
7. Extract that artifact ZIP. The file to install is `witherqueen-recreation-1.21.1-0.1.0.jar`.

If the run is red, open **Compile, test and reobfuscate mod**, and send the error text or build log back for correction. A red run does not produce a usable mod. Actions availability and usage limits depend on your GitHub account and repository.

Alternatively, upload this project's **contents** to a repository root, including `.github/workflows/build.yml`. Do not upload only the source ZIP; GitHub does not automatically unpack it.

## Build on a computer

Install a Java 21 JDK and Gradle 8.8. In the folder containing `build.gradle`, run:

```sh
gradle --no-daemon clean build
```

Output after a successful build: `build/libs/witherqueen-recreation-1.21.1-0.1.0.jar`.

This archive intentionally does not contain a downloaded Gradle wrapper binary. The GitHub workflow installs Gradle automatically. To add a wrapper locally after installing Gradle, run `gradle wrapper --gradle-version 8.8`.

## Install after the build succeeds

1. Install and start a **Forge 1.21.1** Minecraft profile once, then close the game.
2. Put the built **JAR** in that profile's `mods` folder. The ZIP and YAML are not mods.
3. Start the Forge profile. On a server, install the same JAR on the server and every joining client.
4. Test in a new Creative world first, with difficulty set to Normal. Open terrain is best; allow about 40 × 40 blocks for dodging.
5. Search the Creative inventory for **Wither Queen Spawn Egg**, or use:

```mcfunction
/summon witherqueen:wither_queen ~ ~ ~5
```

She ignores Creative/Spectator players. Equip armor, then switch to Survival to start the fight. The first transformation gives you a brief preparation window.

For a quick equipment set, run this as a player with commands enabled:

```mcfunction
/function witherqueen:kit
```

## Survival summoning and rewards

Craft a **Crown Sigil** using the following crafting-table arrangement:

| | | |
|---|---|---|
| Obsidian | Wither Skeleton Skull | Obsidian |
| Wither Skeleton Skull | Nether Star | Wither Skeleton Skull |
| Obsidian | Amethyst Shard | Obsidian |

Use the sigil on a block in an open area. A successful survival summon consumes it. The Queen drops a Royal Scythe, Queen's Crown and Nether Star when mob loot is enabled. The crown is a trophy item, not wearable armor.

**Royal Scythe:** ordinary melee attack, plus right-click Soul Sweep over a five-block cone. Soul Sweep has a 2.25-second cooldown and costs three durability.

## Fighting the Queen

| Attack | Warning and response |
|---|---|
| Scythe combos | Raised arm, then three strikes. Back away or move behind her. |
| Dash | Purple ground line, then a forward lunge. Move sideways after she locks direction. |
| Skull volley | Arms spread and skulls move forward. Keep moving or use cover. |
| Eclipse ring | Circular warning, then a low expanding wave. Jump over it or get outside its radius. |
| Soul beam | Ground line marks her aim before a bright forward beam. Sidestep or use solid cover. |
| Half-health transformation | She takes reduced damage during the transformation and then attacks faster. |

## Differences from the references

This is **not** the original Ares / Super_Awesome_Baby mod, an extracted copy, or a verified 1:1 recreation. The original model files, animations, sounds, source code and exact attack parameters were unavailable. The visible movement and attack themes informed new code and geometry.

The source does not include the videos' arena map, player combat overhaul, custom shaders, music, cutscenes or red player-weapon effects. Boss animations are procedural; the scythe effects use vanilla particles. There is no shader-based bloom. The two special attacks approximate what is visible, rather than reproducing unavailable mechanics exactly. The missing third clip was not used.

## Verification status

See `VALIDATION.md`. Java syntax and isolated combat mathematics were checked. These checks do **not** prove Forge API compatibility, a successful mod build, correct in-game rendering or multiplayer behavior.

## Technical references

- Forge setup: https://docs.minecraftforge.net/en/1.21.x/gettingstarted/
- Forge 1.21.1 downloads: https://files.minecraftforge.net/net/minecraftforge/forge/index_1.21.1.html
- GitHub Gradle builds: https://docs.github.com/en/actions/tutorials/build-and-test-code/java-with-gradle
- Original visual reference: https://www.patreon.com/Super_Awesome_Baby/posts/ares-boss-test-9-168421713

All supplied project code and textures are original recreation assets. No downloaded Ares assets or video files are included.
