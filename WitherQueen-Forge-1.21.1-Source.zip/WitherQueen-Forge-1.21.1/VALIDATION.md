# Validation — 0.1.0

Date: 2 October 2026.

## Completed

- Java compiler syntax parsing succeeded for all 12 project Java source/test files.
- The two dependency-free combat classes and their test runner compiled with the available Java 17 compiler module; 26 assertions passed. Production still targets Java 21.
- Tests cover facing-direction hit cones, reach limits, zero-distance targets, finite beam endpoints, degenerate segments, ring expansion bounds, invalid action IDs and strike timing after attack warnings.
- Nine JSON resources, mods.toml and pack.mcmeta parsed successfully.
- All five PNG files decoded successfully; item texture references and literal translation keys resolve.
- Common/server Java files contain no imports from net.minecraft.client.
- The Java model construction routine was evaluated with local geometry-recording helpers: 160 boxes, no invalid dimensions. A static geometry preview was inspected. This was not a Minecraft render.
- Both workflow files were parsed; the embedded source payload, checksum and extracted file bytes were verified locally. Its texture generator was run against an extracted copy.

## Not completed

- Full Forge compilation and reobfuscation: dependency download returned HTTP 403 in this environment. No full Minecraft/Forge classpath was available.
- Minecraft launch, rendering, gameplay, dedicated-server loading and multiplayer testing.
- The remote GitHub Actions workflow has not been run. It is provided for the first full build and may reveal API/build corrections that still need to be made.

No installable JAR is represented as tested or included.

## Next verification

Run the supplied workflow. After a successful build, launch Forge 1.21.1 with the JAR in a new test world. Spawn the Queen, verify all six attacks and both transformations, defeat her and check the rewards. Test an unloaded/reloaded boss and a dedicated server before using an existing survival save.
