import com.sun.source.util.JavacTask;
import javax.tools.Diagnostic;
import javax.tools.DiagnosticCollector;
import javax.tools.JavaCompiler;
import javax.tools.JavaFileObject;
import javax.tools.StandardJavaFileManager;
import javax.tools.ToolProvider;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

/** Syntax-only verification when the Minecraft/Forge classpath is unavailable. */
public class ParseSources {
    public static void main(String[] args) throws Exception {
        JavaCompiler compiler=ToolProvider.getSystemJavaCompiler();
        if(compiler==null) throw new IllegalStateException("A compiler module is required");
        DiagnosticCollector<JavaFileObject> diagnostics=new DiagnosticCollector<>();
        try(StandardJavaFileManager manager=compiler.getStandardFileManager(diagnostics,null,null);
            var paths=Files.walk(Path.of(args.length==0?"src":args[0]))) {
            var files=paths.filter(p->p.toString().endsWith(".java")).toList();
            JavacTask task=(JavacTask)compiler.getTask(null,manager,diagnostics,
                    List.of("-proc:none"),null,manager.getJavaFileObjectsFromPaths(files));
            int count=0;
            for(var unit:task.parse()) count++;
            boolean failed=false;
            for(var d:diagnostics.getDiagnostics()) {
                System.out.println(d);
                if(d.getKind()==Diagnostic.Kind.ERROR) failed=true;
            }
            if(failed) throw new IllegalStateException("Java syntax errors");
            System.out.println("Parsed "+count+" Java files successfully. This does not resolve Minecraft/Forge APIs.");
        }
    }
}
