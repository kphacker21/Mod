"""Generate the original, precisely mapped pixel atlas and mod data. Requires Pillow."""
from pathlib import Path
import json
import random
from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parents[1] / "src/main/resources"
ASSETS = ROOT / "assets/witherqueen"

def write_json(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")

def save(image, path):
    path.parent.mkdir(parents=True, exist_ok=True)
    image.save(path)

palette = [(35,38,49),(18,19,29),(158,162,181),(220,200,196),
           (98,96,125),(37,38,63),(112,127,166),(225,242,255),
           (255,66,107),(164,126,251),(35,38,49),(35,38,49),
           (35,38,49),(35,38,49),(35,38,49),(35,38,49)]
atlas = Image.new("RGBA", (256,256))
glow = Image.new("RGBA", (256,256))
rng = random.Random(211)
for cell, color in enumerate(palette):
    ox, oy = cell % 4 * 64, cell // 4 * 64
    for y in range(64):
        for x in range(64):
            grain = rng.randint(-3,3) if cell == 3 else rng.randint(-7,7)
            if cell in (0,2,4,6) and (x + 2*y) % 17 == 0: grain += 9
            rgb = tuple(max(0,min(255,c+grain)) for c in color)
            atlas.putpixel((ox+x,oy+y),rgb+(255,))
            if cell in (7,8,9): glow.putpixel((ox+x,oy+y),rgb+(255,))
save(atlas, ASSETS/"textures/entity/queen.png")
save(glow, ASSETS/"textures/entity/queen_glow.png")

scythe=Image.new("RGBA",(64,64)); d=ImageDraw.Draw(scythe)
d.line([(13,57),(37,8)],fill=(16,17,30),width=6)
d.line([(13,57),(37,8)],fill=(115,116,151),width=3)
for x,y in [(17,48),(22,38),(27,28),(32,18)]: d.rectangle([x-2,y,x+2,y+2],fill=(197,203,222))
d.polygon([(24,14),(32,5),(43,3),(54,8),(60,19),(59,29),(53,37),(54,24),(50,15),(43,11),(36,11)],fill=(17,20,37))
d.polygon([(25,13),(33,6),(43,4),(53,9),(59,19),(58,29),(54,34),(55,23),(51,14),(43,10),(35,10)],fill=(170,157,234))
d.line([(25,13),(33,6),(43,4),(53,9),(59,19),(58,29),(54,34)],fill=(239,252,255),width=2)
d.polygon([(33,11),(37,8),(40,12),(36,16)],fill=(160,96,247))
save(scythe,ASSETS/"textures/item/royal_scythe.png")

crown=Image.new("RGBA",(32,32));d=ImageDraw.Draw(crown)
d.polygon([(3,11),(9,17),(15,5),(22,17),(29,11),(26,27),(6,27)],fill=(16,18,29))
d.polygon([(5,13),(10,19),(15,8),(21,19),(27,13),(24,25),(8,25)],fill=(137,141,164))
d.rectangle([7,22,25,26],fill=(79,74,118));d.line([(8,23),(24,23)],fill=(221,226,245))
d.polygon([(16,15),(19,20),(16,24),(13,20)],fill=(190,130,255))
save(crown,ASSETS/"textures/item/queen_crown.png")

sigil=Image.new("RGBA",(32,32));d=ImageDraw.Draw(sigil)
d.ellipse([2,2,29,29],fill=(20,20,33),outline=(193,161,250),width=2)
d.ellipse([6,6,25,25],outline=(114,97,175),width=1)
d.polygon([(10,11),(12,15),(16,8),(20,15),(22,11),(21,19),(11,19)],fill=(210,212,232))
d.rectangle([13,20,18,24],fill=(150,106,255));d.rectangle([14,11,17,14],fill=(187,118,255))
save(sigil,ASSETS/"textures/item/crown_sigil.png")

for name in ("royal_scythe","queen_crown","crown_sigil"):
    model={"parent":"minecraft:item/handheld" if name=="royal_scythe" else "minecraft:item/generated",
           "textures":{"layer0":"witherqueen:item/"+name}}
    if name=="royal_scythe":
        model["display"]={
            "thirdperson_righthand":{"rotation":[0,-90,55],"translation":[0,4,1],"scale":[1.5,1.5,1.5]},
            "thirdperson_lefthand":{"rotation":[0,90,-55],"translation":[0,4,1],"scale":[1.5,1.5,1.5]},
            "firstperson_righthand":{"rotation":[0,-90,25],"translation":[1.13,3.2,1.13],"scale":[0.9,0.9,0.9]}}
    write_json(ASSETS/f"models/item/{name}.json",model)
write_json(ASSETS/"models/item/wither_queen_spawn_egg.json",{"parent":"minecraft:item/template_spawn_egg"})

write_json(ASSETS/"lang/en_us.json",{
    "entity.witherqueen.wither_queen":"Wither Queen",
    "entity.witherqueen.royal_skull":"Royal Skull",
    "boss.witherqueen.enraged":"Wither Queen - Eclipse Unbound",
    "item.witherqueen.wither_queen_spawn_egg":"Wither Queen Spawn Egg",
    "item.witherqueen.crown_sigil":"Crown Sigil",
    "item.witherqueen.queen_crown":"Queen's Crown",
    "item.witherqueen.royal_scythe":"Royal Scythe",
    "tooltip.witherqueen.sigil":"Use on a block to summon the Wither Queen.",
    "tooltip.witherqueen.sigil_room":"Choose a large, open arena. Summoning consumes this sigil.",
    "tooltip.witherqueen.scythe":"Right-click: Soul Sweep. Cooldown: 2.25 seconds.",
    "message.witherqueen.no_room":"Not enough room. Find an open area with at least 4 blocks of height."
})

write_json(ROOT/"data/witherqueen/recipe/crown_sigil.json",{
    "type":"minecraft:crafting_shaped","category":"misc","pattern":["OWO","WNW","OAO"],
    "key":{"O":{"item":"minecraft:obsidian"},"W":{"item":"minecraft:wither_skeleton_skull"},
           "N":{"item":"minecraft:nether_star"},"A":{"item":"minecraft:amethyst_shard"}},
    "result":{"id":"witherqueen:crown_sigil","count":1}})
write_json(ROOT/"data/witherqueen/loot_table/entities/wither_queen.json",{
    "type":"minecraft:entity","pools":[
        {"rolls":1,"entries":[{"type":"minecraft:item","name":"witherqueen:royal_scythe"}]},
        {"rolls":1,"entries":[{"type":"minecraft:item","name":"witherqueen:queen_crown"}]},
        {"rolls":1,"entries":[{"type":"minecraft:item","name":"minecraft:nether_star"}]}
    ]})
write_json(ROOT/"data/minecraft/tags/entity_type/freeze_immune_entity_types.json",{
    "replace":False,"values":["witherqueen:wither_queen","witherqueen:royal_skull"]})
write_json(ROOT/"data/minecraft/tags/entity_type/undead.json",{
    "replace":False,"values":["witherqueen:wither_queen"]})
kit=ROOT/"data/witherqueen/function/kit.mcfunction";kit.parent.mkdir(parents=True,exist_ok=True)
kit.write_text("\n".join("give @s "+item for item in [
    "witherqueen:wither_queen_spawn_egg","witherqueen:royal_scythe","minecraft:netherite_helmet",
    "minecraft:netherite_chestplate","minecraft:netherite_leggings","minecraft:netherite_boots",
    "minecraft:shield","minecraft:golden_apple 16","minecraft:totem_of_undying"]) + "\n")
print("Generated original textures, item models, language, recipe, loot and tags.")
