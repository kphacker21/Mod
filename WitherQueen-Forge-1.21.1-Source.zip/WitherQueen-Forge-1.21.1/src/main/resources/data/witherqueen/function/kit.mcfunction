give @s witherqueen:wither_queen_spawn_egg
give @s witherqueen:royal_scythe
give @s minecraft:netherite_helmet
give @s minecraft:netherite_chestplate
give @s minecraft:netherite_leggings
give @s minecraft:netherite_boots
give @s minecraft:shield
give @s minecraft:golden_apple 16
give @s minecraft:totem_of_undying
