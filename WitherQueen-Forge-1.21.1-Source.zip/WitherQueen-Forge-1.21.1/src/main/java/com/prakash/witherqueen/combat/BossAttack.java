package com.prakash.witherqueen.combat;

/** One authoritative timeline drives damage, animation and effects. Ticks = 1/20 s. */
public enum BossAttack {
    IDLE(0, 0),
    TRANSFORM(64, 64),
    COMBO_ONE(66, 16, 20, 38, 54),
    COMBO_TWO(78, 18, 22, 44, 62),
    DASH(56, 20),
    SKULL_VOLLEY(88, 18, 24, 36, 48, 60, 72),
    ECLIPSE(102, 40),
    SOUL_BEAM(90, 34);

    public final int duration;
    public final int lockTick;
    private final int[] strikes;

    BossAttack(int duration, int lockTick, int... strikes) {
        this.duration = duration;
        this.lockTick = lockTick;
        this.strikes = strikes;
    }

    public boolean strikesAt(int tick) {
        for (int t : strikes) if (t == tick) return true;
        return false;
    }

    public static BossAttack fromId(int id) {
        return id >= 0 && id < values().length ? values()[id] : IDLE;
    }
}
