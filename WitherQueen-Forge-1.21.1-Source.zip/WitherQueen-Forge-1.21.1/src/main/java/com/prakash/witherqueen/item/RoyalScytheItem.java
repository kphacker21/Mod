package com.prakash.witherqueen.item;

import com.prakash.witherqueen.combat.CombatRules;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tiers;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

import java.util.List;

public final class RoyalScytheItem extends SwordItem {
    public RoyalScytheItem() {
        super(Tiers.NETHERITE, new Properties().fireResistant()
                .attributes(SwordItem.createAttributes(Tiers.NETHERITE, 5, -2.8F)));
    }

    @Override public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (player.getCooldowns().isOnCooldown(this)) return InteractionResultHolder.fail(stack);
        if (level instanceof ServerLevel server) {
            for (LivingEntity victim : level.getEntitiesOfClass(LivingEntity.class,
                    player.getBoundingBox().inflate(5, 1, 5),
                    e -> e != player && e.isAlive() && !player.isAlliedTo(e))) {
                if (victim instanceof Player other && (!player.canHarmPlayer(other) || other.isCreative() || other.isSpectator())) continue;
                if (!CombatRules.inCone(victim.getX()-player.getX(), victim.getZ()-player.getZ(),
                        player.getYRot(), 5, 70) || !player.hasLineOfSight(victim)) continue;
                if (victim.hurt(player.damageSources().playerAttack(player), 8))
                    victim.knockback(0.65, player.getX()-victim.getX(), player.getZ()-victim.getZ());
            }
            for (int i=0;i<30;i++) {
                double angle = Math.toRadians(player.getYRot()-70+i*140.0/29);
                server.sendParticles(ParticleTypes.END_ROD, player.getX()-Math.sin(angle)*4,
                        player.getY()+1, player.getZ()+Math.cos(angle)*4, 1, 0, 0, 0, 0);
            }
            level.playSound(null, player.blockPosition(), SoundEvents.PLAYER_ATTACK_SWEEP, SoundSource.PLAYERS, 1, 0.7F);
            player.getCooldowns().addCooldown(this, 45);
            stack.hurtAndBreak(3, player, hand == InteractionHand.MAIN_HAND ? EquipmentSlot.MAINHAND : EquipmentSlot.OFFHAND);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }

    @Override public void appendHoverText(ItemStack stack, TooltipContext context,
                                          List<Component> lines, TooltipFlag flag) {
        lines.add(Component.translatable("tooltip.witherqueen.scythe"));
    }
}
