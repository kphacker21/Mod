package com.prakash.witherqueen.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import com.prakash.witherqueen.WitherQueenMod;
import com.prakash.witherqueen.entity.RoyalSkullEntity;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;

public final class SkullRenderer extends EntityRenderer<RoyalSkullEntity> {
    public static final ModelLayerLocation LAYER=new ModelLayerLocation(
            ResourceLocation.fromNamespaceAndPath(WitherQueenMod.MOD_ID,"royal_skull"),"main");
    private final ModelPart skull;
    public SkullRenderer(EntityRendererProvider.Context context) {
        super(context);
        skull=context.bakeLayer(LAYER);
    }
    public static LayerDefinition createLayer() {
        MeshDefinition mesh=new MeshDefinition();
        QueenModel.addSkull(mesh.getRoot(),"head",PartPose.ZERO,1);
        return LayerDefinition.create(mesh,256,256);
    }
    @Override public ResourceLocation getTextureLocation(RoyalSkullEntity entity) { return QueenRenderer.TEXTURE; }
    @Override public void render(RoyalSkullEntity entity,float yaw,float partialTick,PoseStack poses,
                                 MultiBufferSource buffers,int light) {
        poses.pushPose();
        poses.mulPose(Axis.YP.rotationDegrees(180-yaw));
        poses.scale(-1,-1,1);
        skull.render(poses,buffers.getBuffer(RenderType.entityCutoutNoCull(QueenRenderer.TEXTURE)),light,OverlayTexture.NO_OVERLAY);
        skull.render(poses,buffers.getBuffer(RenderType.eyes(QueenRenderer.GLOW)),15728880,OverlayTexture.NO_OVERLAY);
        poses.popPose();
        super.render(entity,yaw,partialTick,poses,buffers,light);
    }
}
