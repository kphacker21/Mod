package com.prakash.witherqueen.client;

import com.prakash.witherqueen.WitherQueenMod;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = WitherQueenMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientEvents {
    private ClientEvents() { }

    @SubscribeEvent public static void registerLayers(EntityRenderersEvent.RegisterLayerDefinitions event) {
        event.registerLayerDefinition(QueenModel.LAYER, QueenModel::createBodyLayer);
        event.registerLayerDefinition(SkullRenderer.LAYER, SkullRenderer::createLayer);
    }

    @SubscribeEvent public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(WitherQueenMod.QUEEN.get(), QueenRenderer::new);
        event.registerEntityRenderer(WitherQueenMod.SKULL.get(), SkullRenderer::new);
    }
}
