package com.prakash.witherqueen;

import com.prakash.witherqueen.entity.RoyalSkullEntity;
import com.prakash.witherqueen.entity.WitherQueenEntity;
import com.prakash.witherqueen.item.CrownSigilItem;
import com.prakash.witherqueen.item.RoyalScytheItem;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

@Mod(WitherQueenMod.MOD_ID)
public final class WitherQueenMod {
    public static final String MOD_ID = "witherqueen";
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, MOD_ID);
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, MOD_ID);

    public static final RegistryObject<EntityType<WitherQueenEntity>> QUEEN = ENTITIES.register(
            "wither_queen", () -> EntityType.Builder.of(WitherQueenEntity::new, MobCategory.MONSTER)
                    .sized(1.25F, 2.9F).fireImmune().clientTrackingRange(12).updateInterval(2)
                    .build(MOD_ID + ":wither_queen"));
    public static final RegistryObject<EntityType<RoyalSkullEntity>> SKULL = ENTITIES.register(
            "royal_skull", () -> EntityType.Builder.<RoyalSkullEntity>of(RoyalSkullEntity::new, MobCategory.MISC)
                    .sized(0.5F, 0.5F).fireImmune().noSave().clientTrackingRange(10).updateInterval(1)
                    .build(MOD_ID + ":royal_skull"));

    public static final RegistryObject<Item> EGG = ITEMS.register("wither_queen_spawn_egg",
            () -> new ForgeSpawnEggItem(QUEEN, 0x171923, 0xB29CEB, new Item.Properties()));
    public static final RegistryObject<Item> SIGIL = ITEMS.register("crown_sigil",
            () -> new CrownSigilItem(new Item.Properties().stacksTo(1).fireResistant()));
    public static final RegistryObject<Item> CROWN = ITEMS.register("queen_crown",
            () -> new Item(new Item.Properties().stacksTo(16).fireResistant()));
    public static final RegistryObject<Item> SCYTHE = ITEMS.register("royal_scythe", RoyalScytheItem::new);

    public WitherQueenMod(FMLJavaModLoadingContext context) {
        IEventBus bus = context.getModEventBus();
        ENTITIES.register(bus);
        ITEMS.register(bus);
        bus.addListener(this::attributes);
        bus.addListener(this::creativeItems);
    }

    private void attributes(EntityAttributeCreationEvent event) {
        event.put(QUEEN.get(), WitherQueenEntity.createAttributes().build());
    }

    private void creativeItems(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.SPAWN_EGGS) event.accept(EGG.get());
        if (event.getTabKey() == CreativeModeTabs.COMBAT) {
            event.accept(SCYTHE.get());
            event.accept(SIGIL.get());
            event.accept(CROWN.get());
        }
    }
}
