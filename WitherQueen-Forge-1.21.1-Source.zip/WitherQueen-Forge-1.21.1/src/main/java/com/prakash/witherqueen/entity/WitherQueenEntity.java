package com.prakash.witherqueen.entity;

import com.prakash.witherqueen.WitherQueenMod;
import com.prakash.witherqueen.combat.BossAttack;
import com.prakash.witherqueen.combat.CombatRules;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.BossEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public final class WitherQueenEntity extends Monster {
    private static final EntityDataAccessor<Integer> PHASE =
            SynchedEntityData.defineId(WitherQueenEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> ACTION =
            SynchedEntityData.defineId(WitherQueenEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Long> ACTION_START =
            SynchedEntityData.defineId(WitherQueenEntity.class, EntityDataSerializers.LONG);

    private final ServerBossEvent bossBar = new ServerBossEvent(
            Component.translatable("entity.witherqueen.wither_queen"),
            BossEvent.BossBarColor.PURPLE, BossEvent.BossBarOverlay.PROGRESS);
    private final Set<UUID> alreadyHit = new HashSet<>();
    private int restTicks = 25;
    private BossAttack previousAttack = BossAttack.IDLE;
    private Vec3 lockedDirection = new Vec3(0, 0, 1);

    public WitherQueenEntity(EntityType<? extends WitherQueenEntity> type, Level level) {
        super(type, level);
        xpReward = 150;
        setPersistenceRequired();
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 600)
                .add(Attributes.ARMOR, 12)
                .add(Attributes.ARMOR_TOUGHNESS, 4)
                .add(Attributes.ATTACK_DAMAGE, 10)
                .add(Attributes.MOVEMENT_SPEED, 0.28)
                .add(Attributes.FOLLOW_RANGE, 48)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.9);
    }

    @Override protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        targetSelector.addGoal(1, new HurtByTargetGoal(this));
        targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    @Override protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(PHASE, 0);
        builder.define(ACTION, BossAttack.IDLE.ordinal());
        builder.define(ACTION_START, 0L);
    }

    public int phase() { return entityData.get(PHASE); }
    public BossAttack attack() { return BossAttack.fromId(entityData.get(ACTION)); }
    public float attackAge(float partialTick) {
        return Math.max(0, level().getGameTime() - entityData.get(ACTION_START)) + partialTick;
    }

    @Override public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("QueenPhase", phase());
    }

    @Override public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        entityData.set(PHASE, Math.max(0, Math.min(2, tag.getInt("QueenPhase"))));
        // Never resume a damaging attack with an old target or stale world time.
        entityData.set(ACTION, BossAttack.IDLE.ordinal());
        entityData.set(ACTION_START, level().getGameTime());
        restTicks = 40;
    }

    @Override public void startSeenByPlayer(ServerPlayer player) {
        super.startSeenByPlayer(player);
        bossBar.addPlayer(player);
    }

    @Override public void stopSeenByPlayer(ServerPlayer player) {
        super.stopSeenByPlayer(player);
        bossBar.removePlayer(player);
    }

    @Override protected void customServerAiStep() {
        super.customServerAiStep();
        bossBar.setProgress(Math.max(0, getHealth() / getMaxHealth()));
        bossBar.setName(hasCustomName() ? getDisplayName() : Component.translatable(
                phase() == 2 ? "boss.witherqueen.enraged" : "entity.witherqueen.wither_queen"));
        bossBar.setColor(phase() == 2 ? BossEvent.BossBarColor.RED : BossEvent.BossBarColor.PURPLE);

        LivingEntity target = getTarget();
        boolean validTarget = canHit(target) && distanceToSqr(target) < 72 * 72;
        if (!validTarget) {
            setTarget(null);
            getNavigation().stop();
            if (attack() != BossAttack.IDLE && attack() != BossAttack.TRANSFORM) begin(BossAttack.IDLE);
        }
        if (phase() == 0 && validTarget) {
            entityData.set(PHASE, 1);
            begin(BossAttack.TRANSFORM);
        } else if (phase() == 1 && getHealth() <= getMaxHealth() * 0.5F) {
            entityData.set(PHASE, 2);
            begin(BossAttack.TRANSFORM);
        }

        if (attack() != BossAttack.IDLE) {
            getNavigation().stop();
            int age = (int) attackAge(0);
            if (validTarget && age < attack().lockTick) {
                faceTarget(target);
                lockedDirection = Vec3.directionFromRotation(0, getYRot());
            }
            if (age == attack().lockTick) lockedDirection = Vec3.directionFromRotation(0, getYRot());
            performAttack(age);
            if (age >= attack().duration) {
                previousAttack = attack();
                begin(BossAttack.IDLE);
                restTicks = phase() == 2 ? 16 + random.nextInt(12) : 30 + random.nextInt(18);
            }
            return;
        }
        if (!validTarget) return;
        faceTarget(target);
        double distance = distanceTo(target);
        if (distance > 4 && tickCount % 8 == 0) getNavigation().moveTo(target, phase() == 2 ? 1.2 : 1.0);
        if (distance <= 4) getNavigation().stop();
        if (restTicks > 0) { restTicks--; return; }
        if (!hasLineOfSight(target)) return;
        begin(chooseAttack(distance));
    }

    private BossAttack chooseAttack(double distance) {
        BossAttack[] choices;
        if (distance > 13) choices = new BossAttack[]{BossAttack.DASH, BossAttack.SKULL_VOLLEY, BossAttack.SOUL_BEAM};
        else if (distance > 6) choices = new BossAttack[]{BossAttack.DASH, BossAttack.SKULL_VOLLEY, BossAttack.ECLIPSE};
        else choices = new BossAttack[]{BossAttack.COMBO_ONE, BossAttack.COMBO_TWO, BossAttack.ECLIPSE};
        BossAttack result = choices[random.nextInt(choices.length)];
        if (result == previousAttack) result = choices[(java.util.Arrays.asList(choices).indexOf(result) + 1) % choices.length];
        return result;
    }

    private void faceTarget(LivingEntity target) {
        float yaw = (float) Math.toDegrees(Math.atan2(target.getZ() - getZ(), target.getX() - getX())) - 90;
        setYRot(yaw);
        setYBodyRot(yaw);
        getLookControl().setLookAt(target, 30, 30);
    }

    private void begin(BossAttack next) {
        entityData.set(ACTION, next.ordinal());
        entityData.set(ACTION_START, level().getGameTime());
        alreadyHit.clear();
        lockedDirection = Vec3.directionFromRotation(0, getYRot());
        if (next == BossAttack.TRANSFORM) playSound(SoundEvents.WITHER_SPAWN, 1.7F, phase() == 2 ? 0.6F : 0.85F);
        else if (next == BossAttack.ECLIPSE || next == BossAttack.SOUL_BEAM)
            playSound(SoundEvents.EVOKER_PREPARE_ATTACK, 1.6F, 0.7F);
    }

    private void performAttack(int age) {
        switch (attack()) {
            case TRANSFORM -> {
                if (age % 3 == 0) ring(1 + age * 0.055, getY() + 0.15, 36, true);
                if (age == 48) {
                    server().sendParticles(ParticleTypes.FLASH, getX(), getY() + 1.5, getZ(), 1, 0, 0, 0, 0);
                    playSound(SoundEvents.WITHER_BREAK_BLOCK, 1.6F, 0.65F);
                }
            }
            case COMBO_ONE, COMBO_TWO -> {
                if (attack().strikesAt(age)) {
                    boolean heavy = attack() == BossAttack.COMBO_TWO;
                    double reach = heavy ? 5.5 : 4.8;
                    strikeCone(reach, heavy ? 100 : 75, heavy ? 12 : 9);
                    slashParticles(reach, age % 2 == 0);
                    playSound(SoundEvents.PLAYER_ATTACK_SWEEP, 1.7F, heavy ? 0.55F : 0.85F);
                }
            }
            case DASH -> {
                if (age < 20 && age % 3 == 0) warningLine(lockedDirection, 12);
                if (age >= 20 && age <= 32) {
                    Vec3 motion = lockedDirection.scale(phase() == 2 ? 1.15 : 0.9);
                    setDeltaMovement(motion.x, getDeltaMovement().y, motion.z);
                    for (LivingEntity victim : targets(getBoundingBox().inflate(1.5).expandTowards(motion))) {
                        if (!alreadyHit.contains(victim.getUUID()) && hasLineOfSight(victim)) {
                            alreadyHit.add(victim.getUUID());
                            hit(victim, 13, 1.1);
                        }
                    }
                    if (age % 2 == 0) ring(1.5, getY() + 1.2, 15, true);
                }
                if (age == 20) playSound(SoundEvents.PHANTOM_FLAP, 1.8F, 0.6F);
                if (age == 33) setDeltaMovement(0, getDeltaMovement().y, 0);
            }
            case SKULL_VOLLEY -> {
                if (attack().strikesAt(age) && canHit(getTarget())) {
                    fireSkull(-1, getTarget());
                    fireSkull(1, getTarget());
                    playSound(SoundEvents.WITHER_SHOOT, 1.2F, 0.9F);
                }
            }
            case ECLIPSE -> {
                if (age < 42 && age % 3 == 0) ring(3.0, getY() + 0.1, 40, false);
                if (age >= 42 && age <= 78) {
                    double radius = CombatRules.eclipseRadius(age);
                    if (age % 2 == 0) ring(radius, getY() + 0.25, 64, true);
                    for (LivingEntity victim : targets(getBoundingBox().inflate(radius + 1.0, 2, radius + 1.0))) {
                        double dx = victim.getX()-getX(), dz = victim.getZ()-getZ();
                        double horizontal = Math.sqrt(dx*dx + dz*dz);
                        if (Math.abs(horizontal - radius) <= 0.9 && victim.getY() < getY()+1.0
                                && victim.getY()+victim.getBbHeight() > getY()-0.5
                                && !alreadyHit.contains(victim.getUUID()) && hasLineOfSight(victim)) {
                            alreadyHit.add(victim.getUUID());
                            hit(victim, 16, 1.0);
                        }
                    }
                }
                if (age == 42) playSound(SoundEvents.WITHER_BREAK_BLOCK, 1.7F, 0.55F);
            }
            case SOUL_BEAM -> {
                if (age < 40 && age % 3 == 0) warningLine(lockedDirection, 26);
                if (age >= 40 && age <= 56 && age % 2 == 0) beam();
                if (age == 40) playSound(SoundEvents.WITHER_SHOOT, 2, 0.55F);
            }
            default -> { }
        }
    }

    private ServerLevel server() { return (ServerLevel) level(); }

    private boolean canHit(LivingEntity victim) {
        return victim != null && victim != this && victim.isAlive()
                && !(victim instanceof WitherQueenEntity) && !isAlliedTo(victim)
                && (!(victim instanceof Player player) || (!player.isCreative() && !player.isSpectator()));
    }

    private java.util.List<LivingEntity> targets(AABB area) {
        return level().getEntitiesOfClass(LivingEntity.class, area, this::canHit);
    }

    private void hit(LivingEntity victim, float damage, double knockback) {
        if (victim.hurt(damageSources().mobAttack(this), damage * (phase() == 2 ? 1.2F : 1))) {
            victim.addEffect(new MobEffectInstance(MobEffects.WITHER, 80, 0), this);
            victim.knockback(knockback, getX() - victim.getX(), getZ() - victim.getZ());
        }
    }

    private void strikeCone(double reach, double halfAngle, float damage) {
        for (LivingEntity victim : targets(getBoundingBox().inflate(reach, 1.0, reach))) {
            if (CombatRules.inCone(victim.getX() - getX(), victim.getZ() - getZ(), getYRot(), reach, halfAngle)
                    && hasLineOfSight(victim)) hit(victim, damage, 0.7);
        }
    }

    private void fireSkull(int side, LivingEntity target) {
        Vec3 right = new Vec3(lockedDirection.z, 0, -lockedDirection.x);
        Vec3 origin = position().add(0, 2.35, 0).add(right.scale(side * 1.35));
        Vec3 aim = target.getBoundingBox().getCenter().subtract(origin).normalize();
        RoyalSkullEntity skull = new RoyalSkullEntity(WitherQueenMod.SKULL.get(), level());
        skull.launch(this, origin, aim.scale(phase() == 2 ? 0.65 : 0.5), phase() == 2 ? 10 : 8);
        level().addFreshEntity(skull);
    }

    private void beam() {
        Vec3 start = position().add(0, 1.4, 0);
        Vec3 desiredEnd = start.add(lockedDirection.scale(26));
        HitResult clip = level().clip(new ClipContext(start, desiredEnd, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, this));
        Vec3 end = clip.getLocation();
        double length = start.distanceTo(end);
        for (double d = 0; d <= length; d += 0.6) {
            Vec3 p = start.add(lockedDirection.scale(d));
            server().sendParticles(ParticleTypes.END_ROD, p.x, p.y, p.z, 1, 0.12, 0.12, 0.12, 0.015);
        }
        for (LivingEntity victim : targets(new AABB(start, end).inflate(1.2))) {
            Vec3 point = victim.getBoundingBox().getCenter();
            double tolerance = 0.55 + victim.getBbWidth() * 0.5;
            if (CombatRules.segmentDistanceSquared(point.x,point.y,point.z, start.x,start.y,start.z, end.x,end.y,end.z)
                    <= tolerance*tolerance && hasLineOfSight(victim) && alreadyHit.add(victim.getUUID())) hit(victim, 19, 0.8);
        }
    }

    private void warningLine(Vec3 direction, double length) {
        DustParticleOptions dust = new DustParticleOptions(new Vector3f(0.85F, 0.25F, 1), 1.3F);
        for (double d = 1; d < length; d += 1) {
            Vec3 p = position().add(direction.scale(d)).add(0, 0.2, 0);
            server().sendParticles(dust, p.x, p.y, p.z, 1, 0, 0.025, 0, 0);
        }
    }

    private void ring(double radius, double y, int count, boolean bright) {
        for (int i = 0; i < count; i++) {
            double a = i * Math.PI * 2 / count;
            server().sendParticles(bright ? ParticleTypes.END_ROD : ParticleTypes.WITCH,
                    getX()+Math.cos(a)*radius, y, getZ()+Math.sin(a)*radius, 1, 0, 0.02, 0, 0);
        }
    }

    private void slashParticles(double reach, boolean reversed) {
        for (int i = 0; i < 32; i++) {
            double a = Math.toRadians(getYRot() - 95 + i * 190.0 / 31);
            server().sendParticles(ParticleTypes.END_ROD, getX()-Math.sin(a)*reach,
                    getY()+1.1+(reversed ? i : 31-i)*0.025, getZ()+Math.cos(a)*reach, 1, 0, 0, 0, 0);
        }
    }

    @Override public boolean hurt(DamageSource source, float amount) {
        return super.hurt(source, attack() == BossAttack.TRANSFORM ? amount * 0.35F : amount);
    }
    @Override public boolean canBeAffected(MobEffectInstance effect) {
        return !effect.getEffect().equals(MobEffects.WITHER) && super.canBeAffected(effect);
    }
    @Override protected SoundEvent getHurtSound(DamageSource source) { return SoundEvents.WITHER_HURT; }
    @Override protected SoundEvent getDeathSound() { return SoundEvents.WITHER_DEATH; }
    @Override public boolean removeWhenFarAway(double distance) { return false; }
}
