package com.prakash.witherqueen.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.prakash.witherqueen.WitherQueenMod;
import com.prakash.witherqueen.combat.BossAttack;
import com.prakash.witherqueen.combat.CombatRules;
import com.prakash.witherqueen.entity.WitherQueenEntity;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/** Original cuboid rig. Atlas cells supply distinct bone, metal, hair, skin and light materials. */
public final class QueenModel extends EntityModel<WitherQueenEntity> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(
            ResourceLocation.fromNamespaceAndPath(WitherQueenMod.MOD_ID, "wither_queen"), "main");
    private final ModelPart root, core, head, armL, armR, foreL, foreR, thighL, thighR;
    private final ModelPart skirt, skullL, skullR, scytheL, scytheR, mantle;
    public QueenModel(ModelPart root) {
        this.root = root;
        core = root.getChild("core");
        head = core.getChild("head");
        armL = core.getChild("arm_l"); armR = core.getChild("arm_r");
        foreL = armL.getChild("forearm"); foreR = armR.getChild("forearm");
        scytheL = foreL.getChild("scythe"); scytheR = foreR.getChild("scythe");
        thighL = core.getChild("thigh_l"); thighR = core.getChild("thigh_r");
        skirt = core.getChild("skirt"); mantle = core.getChild("mantle");
        skullL = root.getChild("skull_l"); skullR = root.getChild("skull_r");
    }

    // 64x64 material cells; every box UV stays inside its material cell.
    private static CubeListBuilder material(int index) {
        return CubeListBuilder.create().texOffs((index % 4) * 64, (index / 4) * 64);
    }
    private static PartDefinition box(PartDefinition parent, String name, int mat,
                                       float x, float y, float z, float w, float h, float d, PartPose pose) {
        return parent.addOrReplaceChild(name, material(mat).addBox(x,y,z,w,h,d), pose);
    }
    private static PartDefinition pivot(PartDefinition parent, String name, PartPose pose) {
        return parent.addOrReplaceChild(name, CubeListBuilder.create(), pose);
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition core = pivot(root,"core",PartPose.offset(0,11,0));
        box(core,"hips",0,-3.6F,-2,-2.3F,7.2F,3,4.6F,PartPose.ZERO);
        box(core,"waist",0,-2.8F,-6,-2,5.6F,4,4,PartPose.ZERO);
        box(core,"chest",0,-4,-10,-2.5F,8,5,5,PartPose.ZERO);
        box(core,"collar",2,-4.6F,-10.4F,-3,9.2F,1.2F,6,PartPose.ZERO);
        box(core,"sternum",2,-0.5F,-9.6F,-2.95F,1,8,0.8F,PartPose.ZERO);
        for (int side : new int[]{-1,1}) {
            for (int i=0;i<4;i++) box(core,"rib"+side+"_"+i,2,0,-0.45F,-0.4F,3.4F,0.9F,1,
                    PartPose.offsetAndRotation(side*0.45F,-8.8F+i*1.65F,-2.9F,0,0,side < 0 ? 2.97F : 0.17F));
        }
        box(core,"heart",9,-0.85F,-8.4F,-3.6F,1.7F,2.1F,0.5F,PartPose.ZERO);
        PartDefinition head = pivot(core,"head",PartPose.offset(0,-10.4F,0));
        box(head,"face",3,-3,-6.5F,-3,6,6.5F,6,PartPose.ZERO);
        box(head,"hair_cap",1,-3.4F,-7.3F,-3.3F,6.8F,2.6F,6.9F,PartPose.ZERO);
        box(head,"hair_back",1,-3.4F,-5.2F,2.4F,6.8F,10,1.4F,PartPose.ZERO);
        for (int side : new int[]{-1,1}) {
            box(head,"sidehair"+side,1,-0.7F,-5.4F,-2.1F,1.4F,10,4.6F,PartPose.offsetAndRotation(side*3.3F,0,0,0,0,-side*0.07F));
            box(head,"fringe"+side,1,-1.1F,-6.7F,-3.6F,2.2F,2.9F,0.9F,PartPose.offsetAndRotation(side*1.5F,0,0,0,0,side*0.18F));
            box(head,"eye"+side,8,-0.8F,-0.4F,-0.1F,1.6F,0.75F,0.25F,PartPose.offset(side*1.5F,-3.6F,-3.1F));
            box(head,"brow"+side,0,-1,-0.25F,-0.1F,2,0.5F,0.3F,PartPose.offsetAndRotation(side*1.5F,-4.2F,-3.15F,0,0,side*0.12F));
            PartDefinition horn = pivot(head,"horn"+side,PartPose.offsetAndRotation(side*3,-6.8F,0,0,0,side*0.4F));
            box(horn,"base",0,-1.1F,-4,-1.1F,2.2F,4,2.2F,PartPose.ZERO);
            box(horn,"tip",2,-0.55F,-3,-0.55F,1.1F,3,1.1F,PartPose.offsetAndRotation(0,-3.5F,0,0,0,-side*0.5F));
        }
        box(head,"crown_band",4,-3.6F,-7.6F,-3.65F,7.2F,1,1.2F,PartPose.ZERO);
        for(int i=-1;i<=1;i++) box(head,"crown_spike"+i,4,-0.5F,-3,-0.5F,1,3,1,
                PartPose.offsetAndRotation(i*2.4F,-7.4F,-3.25F,0,0,i*0.15F));
        box(head,"crown_gem",9,-0.55F,-9.4F,-3.9F,1.1F,1.7F,0.55F,PartPose.ZERO);

        for (int side : new int[]{-1,1}) {
            String suffix = side < 0 ? "r" : "l";
            PartDefinition arm = pivot(core,"arm_"+suffix,PartPose.offset(side*5,-8.6F,0));
            box(arm,"upper",0,-1.4F,0,-1.5F,2.8F,6,3,PartPose.ZERO);
            box(arm,"shoulder",2,-2.2F,-1.1F,-2.1F,4.4F,2.3F,4.2F,PartPose.offsetAndRotation(0,0,0,0,0,-side*0.25F));
            PartDefinition fore = pivot(arm,"forearm",PartPose.offset(0,6,0));
            box(fore,"gauntlet",0,-1.7F,0,-1.8F,3.4F,5.6F,3.6F,PartPose.ZERO);
            for(int i=0;i<3;i++) box(fore,"gauntlet_rib"+i,2,-1.9F,i*1.6F,-2,3.8F,0.5F,4,PartPose.ZERO);
            scythe(fore,"scythe",side);
            PartDefinition thigh = pivot(core,"thigh_"+suffix,PartPose.offset(side*2,0,0));
            box(thigh,"leg",3,-1.6F,0,-1.6F,3.2F,6.5F,3.2F,PartPose.ZERO);
            box(thigh,"boot",0,-1.8F,6,-2,3.6F,7,4,PartPose.ZERO);
            for(int i=0;i<4;i++) box(thigh,"boot_rib"+i,2,-1.9F,6.4F+i*1.5F,-2.15F,3.8F,0.6F,4.3F,PartPose.ZERO);
            box(thigh,"foot",0,-1.9F,11,-3,3.8F,2,5,PartPose.ZERO);
        }
        PartDefinition skirt = pivot(core,"skirt",PartPose.offset(0,-1.2F,0));
        for(int i=0;i<8;i++) {
            double a=i*Math.PI/4;
            PartDefinition plate=pivot(skirt,"panel"+i,PartPose.offsetAndRotation(
                    (float)Math.sin(a)*3.9F,0,(float)Math.cos(a)*2.6F,0,(float)a,0));
            box(plate,"cloth",5,-1.8F,0,0,3.6F,10+(i%2)*2,0.8F,
                    PartPose.offsetAndRotation(0,0,0,0.22F,0,0));
            box(plate,"trim",4,-0.25F,0,-0.2F,0.5F,10+(i%2)*2,1.2F,
                    PartPose.offsetAndRotation(0,0,0,0.22F,0,0));
        }
        PartDefinition mantle = pivot(core,"mantle",PartPose.offset(0,-8,2));
        for(int side:new int[]{-1,1}) for(int i=0;i<4;i++) {
            box(mantle,"spine"+side+"_"+i,2,-0.6F,-0.6F,0,1.2F,1.2F,5.5F,
                    PartPose.offsetAndRotation(side*(3+i*1.7F),i*1.4F,0,-0.2F,side*(0.65F+i*0.14F),0));
        }
        addSkull(root,"skull_l",PartPose.offset(16,-6,1),1.1F);
        addSkull(root,"skull_r",PartPose.offset(-16,-6,1),1.1F);
        for(int side:new int[]{-1,1}) for(int i=0;i<5;i++) {
            box(root,"chain"+side+"_"+i,2,-0.7F,-0.7F,-0.7F,1.4F,1.4F,1.4F,
                    PartPose.offset(side*(7+i*1.5F),3-i*1.4F,2.6F));
        }
        return LayerDefinition.create(mesh,256,256);
    }

    private static void scythe(PartDefinition parent,String name,int side) {
        PartDefinition scythe=pivot(parent,name,PartPose.offsetAndRotation(0,4,-0.2F,0,0,side*0.28F));
        box(scythe,"shaft",4,-0.6F,-19,-0.6F,1.2F,29,1.2F,PartPose.ZERO);
        for(int y=-14;y<=10;y+=4) box(scythe,"wrap"+y,2,-0.8F,y,-0.8F,1.6F,0.7F,1.6F,PartPose.ZERO);
        float[][] points={{0,-18},{4,-20},{8,-20},{12,-18},{15,-14},{16,-10},{15,-6}};
        for(int i=0;i<points.length-1;i++) {
            float dx=(points[i+1][0]-points[i][0])*side,dy=points[i+1][1]-points[i][1];
            float len=Mth.sqrt(dx*dx+dy*dy);
            PartDefinition blade=pivot(scythe,"blade"+i,PartPose.offsetAndRotation(
                    points[i][0]*side,points[i][1],0,0,0,(float)Math.atan2(dy,dx)));
            box(blade,"metal",6,0,-0.9F,-0.65F,len+0.15F,1.8F,1.3F,PartPose.ZERO);
            box(blade,"edge",7,0,-1.05F,-0.72F,len+0.2F,0.45F,1.45F,PartPose.ZERO);
        }
        box(scythe,"jewel",9,-1.1F,-18.4F,-1.1F,2.2F,2.2F,2.2F,PartPose.ZERO);
    }

    static void addSkull(PartDefinition root,String name,PartPose pose,float scale) {
        PartDefinition skull=pivot(root,name,pose);
        box(skull,"cranium",0,-3*scale,-3*scale,-3*scale,6*scale,5*scale,6*scale,PartPose.ZERO);
        box(skull,"jaw",2,-2.6F*scale,2*scale,-2.8F*scale,5.2F*scale,1.3F*scale,5*scale,PartPose.ZERO);
        for(int side:new int[]{-1,1}) {
            box(skull,"socket"+side,1,-1.2F,-0.8F,-0.3F,2.4F,1.6F,0.6F,PartPose.offset(side*1.6F*scale,-0.8F*scale,-3*scale));
            box(skull,"eye"+side,7,-0.6F,-0.25F,-0.2F,1.2F,0.5F,0.5F,PartPose.offset(side*1.6F*scale,-0.7F*scale,-3.2F*scale));
        }
        box(skull,"nose",1,-0.5F,0.2F,-3.35F*scale,1,1.1F,0.4F,PartPose.ZERO);
        for(int i=-2;i<=2;i++) box(skull,"tooth"+i,2,-0.3F,0,-0.3F,0.6F,1,0.6F,PartPose.offset(i*scale,1.4F*scale,-3*scale));
    }

    @Override public void setupAnim(WitherQueenEntity queen,float limbSwing,float limbAmount,
                                    float ageInTicks,float netHeadYaw,float headPitch) {
        root.getAllParts().forEach(ModelPart::resetPose);
        float partial=ageInTicks-queen.tickCount;
        float t=queen.attackAge(partial);
        BossAttack attack=queen.attack();
        float awake=queen.phase()==0?0:(attack==BossAttack.TRANSFORM && queen.phase()==1 ? CombatRules.smooth(t/56):1);
        head.yRot=netHeadYaw*Mth.DEG_TO_RAD*0.55F;
        head.xRot=headPitch*Mth.DEG_TO_RAD*0.35F;
        core.y+=Mth.sin(ageInTicks*0.09F)*0.35F;
        thighL.xRot=Mth.cos(limbSwing*0.66F)*limbAmount*0.8F;
        thighR.xRot=Mth.cos(limbSwing*0.66F+Mth.PI)*limbAmount*0.8F;
        armL.zRot=-0.16F; armR.zRot=0.16F;
        armL.xRot=Mth.cos(limbSwing*0.66F+Mth.PI)*limbAmount*0.35F;
        armR.xRot=Mth.cos(limbSwing*0.66F)*limbAmount*0.35F;
        foreL.xRot=-0.22F; foreR.xRot=-0.22F;
        scytheL.visible=scytheR.visible=awake>0.35F;
        mantle.visible=awake>0.5F;
        skirt.xScale=skirt.zScale=0.8F+awake*0.2F;
        skullL.x+=Mth.sin(ageInTicks*0.055F)*2.3F;
        skullR.x-=Mth.sin(ageInTicks*0.055F)*2.3F;
        skullL.y+=Mth.sin(ageInTicks*0.09F)*1.7F+(1-awake)*5;
        skullR.y+=Mth.cos(ageInTicks*0.09F)*1.7F+(1-awake)*5;
        skullL.yRot=-0.15F+Mth.sin(ageInTicks*0.04F)*0.13F;
        skullR.yRot=0.15F-Mth.sin(ageInTicks*0.04F)*0.13F;
        for(ModelPart plate:skirt.getAllParts().toList()) {
            // The root retains its pose; individual hanging panels sway slightly.
            if(plate!=skirt) plate.xRot+=Mth.sin(ageInTicks*0.065F+plate.x)*0.025F;
        }
        if(attack==BossAttack.TRANSFORM) {
            float rise=Mth.sin(Math.min(1,t/64)*Mth.PI);
            armL.zRot=-0.2F-rise*1.3F;armR.zRot=0.2F+rise*1.3F;
            core.y-=rise*4;head.xRot=-rise*0.3F;
            skullL.x+=rise*5;skullR.x-=rise*5;
            skullL.y-=rise*5;skullR.y-=rise*5;
            scytheL.zRot+=rise*1.2F;scytheR.zRot-=rise*1.2F;
        } else if(attack==BossAttack.COMBO_ONE || attack==BossAttack.COMBO_TWO) {
            float spacing=attack==BossAttack.COMBO_ONE?18:22;
            float first=attack==BossAttack.COMBO_ONE?20:22;
            for(int i=0;i<3;i++) {
                float impact= i==2 ? (attack==BossAttack.COMBO_ONE?54:62) : first+i*spacing;
                float window=t-(impact-13);
                if(window>=0 && window<19) {
                    float swing=CombatRules.smooth(window/15);
                    float arc=-1.5F+swing*3.1F;
                    ModelPart arm=i%2==0?armR:armL;
                    arm.xRot=-1.4F;
                    arm.yRot=(i%2==0?1:-1)*arc;
                    arm.zRot=(i%2==0?1:-1)*0.45F;
                    core.yRot=(i%2==0?1:-1)*arc*0.28F;
                    if(i==2) {armL.xRot=-1.8F+swing*1.4F;armR.xRot=armL.xRot;core.xRot=Mth.sin(swing*Mth.PI)*0.3F;}
                }
            }
        } else if(attack==BossAttack.DASH) {
            float crouch=t<20?CombatRules.smooth(t/15):t<34?1:1-CombatRules.smooth((t-34)/15);
            core.xRot=crouch*0.45F;core.y+=crouch*1.5F;
            armL.xRot=armR.xRot=crouch*1.3F;
            scytheL.zRot=-crouch*0.7F;scytheR.zRot=crouch*0.7F;
        } else if(attack==BossAttack.SKULL_VOLLEY) {
            armL.zRot=-1.15F;armR.zRot=1.15F;
            skullL.x-=4;skullR.x+=4;
            skullL.z=skullR.z=-3-Mth.sin(t*0.5F)*0.5F;
        } else if(attack==BossAttack.ECLIPSE) {
            float raise=CombatRules.smooth(t/28),slam=CombatRules.smooth((t-36)/8);
            armL.xRot=armR.xRot=-raise*2.8F+slam*2.5F;
            armL.zRot=-0.6F;armR.zRot=0.6F;
            core.xRot=slam*0.4F*(1-CombatRules.smooth((t-62)/22));
            core.y-=Mth.sin(Math.min(1,t/45)*Mth.PI)*3;
            scytheL.xScale=scytheL.yScale=scytheL.zScale=1+raise*0.35F*(1-slam);
            scytheR.xScale=scytheR.yScale=scytheR.zScale=scytheL.xScale;
        } else if(attack==BossAttack.SOUL_BEAM) {
            armL.xRot=armR.xRot=-1.6F;
            armL.yRot=-0.5F;armR.yRot=0.5F;
            skullL.x=8;skullR.x=-8;skullL.z=skullR.z=-6;
        }
        if(queen.isDeadOrDying()) {
            core.xRot=CombatRules.smooth(queen.deathTime/20F)*1.3F;
            core.y+=queen.deathTime*0.35F;
            scytheL.visible=scytheR.visible=false;
        }
    }

    @Override public void renderToBuffer(PoseStack poses,VertexConsumer vertices,int light,int overlay,int color) {
        root.render(poses,vertices,light,overlay,color);
    }
}
