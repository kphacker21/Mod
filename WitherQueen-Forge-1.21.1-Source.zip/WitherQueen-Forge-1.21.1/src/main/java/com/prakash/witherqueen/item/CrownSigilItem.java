package com.prakash.witherqueen.item;

import com.prakash.witherqueen.WitherQueenMod;
import com.prakash.witherqueen.entity.WitherQueenEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.context.UseOnContext;

import java.util.List;

public final class CrownSigilItem extends Item {
    public CrownSigilItem(Properties properties) { super(properties); }

    @Override public InteractionResult useOn(UseOnContext context) {
        if (context.getLevel().isClientSide) return InteractionResult.SUCCESS;
        BlockPos pos = context.getClickedPos().relative(context.getClickedFace());
        WitherQueenEntity queen = WitherQueenMod.QUEEN.get().create(context.getLevel());
        if (queen == null) return InteractionResult.FAIL;
        queen.moveTo(pos.getX()+0.5, pos.getY(), pos.getZ()+0.5, context.getRotation()+180, 0);
        if (!context.getLevel().noCollision(queen)) {
            if (context.getPlayer() != null) context.getPlayer().displayClientMessage(
                    Component.translatable("message.witherqueen.no_room"), true);
            return InteractionResult.FAIL;
        }
        if (!context.getLevel().addFreshEntity(queen)) return InteractionResult.FAIL;
        if (context.getPlayer() == null || !context.getPlayer().getAbilities().instabuild)
            context.getItemInHand().shrink(1);
        return InteractionResult.CONSUME;
    }

    @Override public void appendHoverText(ItemStack stack, TooltipContext context,
                                          List<Component> lines, TooltipFlag flag) {
        lines.add(Component.translatable("tooltip.witherqueen.sigil"));
        lines.add(Component.translatable("tooltip.witherqueen.sigil_room"));
    }
}
