package com.prakash.witherqueen.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.prakash.witherqueen.WitherQueenMod;
import com.prakash.witherqueen.entity.WitherQueenEntity;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;

public final class QueenRenderer extends MobRenderer<WitherQueenEntity, QueenModel> {
    static final ResourceLocation TEXTURE=ResourceLocation.fromNamespaceAndPath(WitherQueenMod.MOD_ID,"textures/entity/queen.png");
    static final ResourceLocation GLOW=ResourceLocation.fromNamespaceAndPath(WitherQueenMod.MOD_ID,"textures/entity/queen_glow.png");

    public QueenRenderer(EntityRendererProvider.Context context) {
        super(context,new QueenModel(context.bakeLayer(QueenModel.LAYER)),0.7F);
        addLayer(new Glow(this));
    }
    @Override public ResourceLocation getTextureLocation(WitherQueenEntity entity) { return TEXTURE; }
    @Override protected void scale(WitherQueenEntity entity,PoseStack poses,float partialTick) {
        poses.scale(1.4F,1.4F,1.4F);
    }

    private static final class Glow extends RenderLayer<WitherQueenEntity,QueenModel> {
        Glow(QueenRenderer parent) { super(parent); }
        @Override public void render(PoseStack poses,MultiBufferSource buffers,int light,WitherQueenEntity entity,
                                     float limbSwing,float limbAmount,float partial,float age,float headYaw,float headPitch) {
            if (entity.isInvisible()) return;
            getParentModel().renderToBuffer(poses,buffers.getBuffer(RenderType.eyes(GLOW)),
                    15728880,OverlayTexture.NO_OVERLAY,0xFFFFFFFF);
        }
    }
}
