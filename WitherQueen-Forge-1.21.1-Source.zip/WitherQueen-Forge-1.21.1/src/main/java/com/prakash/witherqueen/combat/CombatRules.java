package com.prakash.witherqueen.combat;

/** Pure geometry, shared by the boss and the player's scythe. */
public final class CombatRules {
    private CombatRules() { }

    public static boolean inCone(double dx, double dz, double yawDegrees,
                                 double reach, double halfAngleDegrees) {
        double d2 = dx * dx + dz * dz;
        if (d2 > reach * reach) return false;
        if (d2 < 0.04) return true;
        double yaw = Math.toRadians(yawDegrees);
        double dot = (-Math.sin(yaw) * dx + Math.cos(yaw) * dz) / Math.sqrt(d2);
        return dot >= Math.cos(Math.toRadians(halfAngleDegrees)) - 1.0E-9;
    }

    public static double segmentDistanceSquared(double px, double py, double pz,
                                                double ax, double ay, double az,
                                                double bx, double by, double bz) {
        double dx = bx - ax, dy = by - ay, dz = bz - az;
        double length2 = dx * dx + dy * dy + dz * dz;
        double t = length2 < 1.0E-12 ? 0 :
                Math.max(0, Math.min(1, ((px-ax)*dx + (py-ay)*dy + (pz-az)*dz) / length2));
        double ex = px - ax - t * dx, ey = py - ay - t * dy, ez = pz - az - t * dz;
        return ex * ex + ey * ey + ez * ez;
    }

    public static double eclipseRadius(int tick) {
        return Math.max(0, Math.min(18, (tick - 42) * 0.5));
    }

    public static float smooth(float value) {
        float t = Math.max(0, Math.min(1, value));
        return t * t * (3 - 2 * t);
    }
}
