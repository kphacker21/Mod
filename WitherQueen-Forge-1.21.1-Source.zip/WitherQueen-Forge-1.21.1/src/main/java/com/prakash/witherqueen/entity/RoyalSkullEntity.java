package com.prakash.witherqueen.entity;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import java.util.Comparator;
import java.util.UUID;

/** A bounded, non-destructive projectile: no vanilla Wither explosions or terrain changes. */
public final class RoyalSkullEntity extends Entity {
    private UUID ownerId;
    private float damage = 8;

    public RoyalSkullEntity(EntityType<? extends RoyalSkullEntity> type, Level level) {
        super(type, level);
        setNoGravity(true);
    }

    public void launch(LivingEntity owner, Vec3 origin, Vec3 velocity, float damage) {
        ownerId = owner.getUUID();
        this.damage = damage;
        setPos(origin.x, origin.y, origin.z);
        setDeltaMovement(velocity);
        setYRot((float) Math.toDegrees(Math.atan2(velocity.z, velocity.x)) - 90);
    }

    @Override protected void defineSynchedData(SynchedEntityData.Builder builder) { }
    @Override protected void readAdditionalSaveData(CompoundTag tag) { }
    @Override protected void addAdditionalSaveData(CompoundTag tag) { }

    @Override public void tick() {
        super.tick();
        if (level().isClientSide) {
            level().addParticle(ParticleTypes.SOUL_FIRE_FLAME, getX(), getY(), getZ(), 0, 0, 0);
            return;
        }
        ServerLevel server = (ServerLevel) level();
        Entity owner = ownerId == null ? null : server.getEntity(ownerId);
        if (tickCount > 120 || owner == null || !owner.isAlive()) { discard(); return; }
        Vec3 start = position(), end = start.add(getDeltaMovement());
        HitResult block = level().clip(new ClipContext(start, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, this));
        Vec3 clippedEnd = block.getLocation();
        var victims = level().getEntitiesOfClass(LivingEntity.class,
                getBoundingBox().expandTowards(getDeltaMovement()).inflate(0.8),
                victim -> victim.isAlive() && victim != owner && !(victim instanceof WitherQueenEntity)
                        && !owner.isAlliedTo(victim)
                        && (!(victim instanceof Player p) || (!p.isCreative() && !p.isSpectator())));
        victims.sort(Comparator.comparingDouble(victim -> victim.distanceToSqr(start)));
        for (LivingEntity victim : victims) {
            var hitBox = victim.getBoundingBox().inflate(0.2);
            var intercept = hitBox.clip(start, clippedEnd);
            if (!hitBox.contains(start) && intercept.isEmpty()) continue;
            Vec3 point = intercept.orElse(start);
            if (victim.hurt(damageSources().indirectMagic(this, owner), damage))
                victim.addEffect(new MobEffectInstance(MobEffects.WITHER, 80, 0), owner);
            impact(server, point);
            return;
        }
        if (block.getType() != HitResult.Type.MISS) { impact(server, clippedEnd); return; }
        setPos(end.x, end.y, end.z);
    }

    private void impact(ServerLevel server, Vec3 at) {
        server.sendParticles(ParticleTypes.SOUL_FIRE_FLAME, at.x, at.y, at.z, 18, 0.25, 0.25, 0.25, 0.04);
        playSound(SoundEvents.WITHER_BREAK_BLOCK, 0.6F, 1.4F);
        discard();
    }
}
