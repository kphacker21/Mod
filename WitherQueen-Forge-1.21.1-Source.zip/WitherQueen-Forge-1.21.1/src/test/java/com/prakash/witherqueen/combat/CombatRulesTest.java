package com.prakash.witherqueen.combat;

public final class CombatRulesTest {
    private static int checks;
    private static void check(boolean value, String why) {
        checks++;
        if (!value) throw new AssertionError(why);
    }
    private static void near(double got, double wanted, String why) {
        check(Math.abs(got - wanted) < 0.00001, why + ": " + got);
    }
    public static void main(String[] args) {
        check(CombatRules.inCone(0, 3, 0, 5, 65), "yaw 0 faces south");
        check(!CombatRules.inCone(0, -3, 0, 5, 65), "a scythe does not hit behind its owner");
        check(CombatRules.inCone(-3, 0, 90, 5, 65), "yaw 90 faces west");
        check(!CombatRules.inCone(0, 5.01, 0, 5, 65), "reach is bounded");
        check(CombatRules.inCone(0, 0, 123, 5, 65), "overlapping target avoids division by zero");
        near(CombatRules.segmentDistanceSquared(2,1,5, 0,0,0, 0,0,10),5,"beam side distance");
        near(CombatRules.segmentDistanceSquared(0,0,15, 0,0,0, 0,0,10),25,"beam cannot hit past its end");
        near(CombatRules.segmentDistanceSquared(1,2,3, 0,0,0, 0,0,0),14,"zero-length beam");
        near(CombatRules.eclipseRadius(30),0,"warning has no damaging radius");
        near(CombatRules.eclipseRadius(62),10,"ring expands predictably");
        near(CombatRules.eclipseRadius(200),18,"ring remains bounded");
        check(BossAttack.fromId(-1) == BossAttack.IDLE, "invalid saved action safely idles");
        check(BossAttack.fromId(999) == BossAttack.IDLE, "future unknown action safely idles");
        for (BossAttack attack : BossAttack.values()) {
            for (int tick = -1; tick < 130; tick++) {
                if (attack.strikesAt(tick)) check(tick >= attack.lockTick && tick < attack.duration,
                        attack + " must telegraph before damaging");
            }
        }
        check(BossAttack.COMBO_ONE.strikesAt(20),"first combo impact");
        check(!BossAttack.COMBO_ONE.strikesAt(21),"impact is not dealt every animation tick");
        System.out.println("Combat checks passed: " + checks);
    }
}
